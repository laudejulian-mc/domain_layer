// This is a placeholder for the Equatable class to avoid errors if the package is not installed.
abstract class Equatable {
  const Equatable();
  List<Object?> get props;
}
